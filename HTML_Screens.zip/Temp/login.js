const loginForm = document.getElementById('studentLoginForm');

loginForm.addEventListener('submit', function (event) {
    event.preventDefault(); 

    const usernameInput = document.getElementById('usernameInput').value.trim();
    const passwordInput = document.getElementById('passwordInput').value.trim(); 
    //fetch the fakeDB.json file
    fetch('fakeDB.json')
        .then(response => {
            if (!response.ok) {
                throw new Error("upload failed");
            }
            return response.json();
        })
        .then(data => {
            // validate user
            const userExists = data.students.some(s => 
                s.username === usernameInput && s.password === passwordInput
            );

            if (userExists) {
                alert("Login successful!");
            } else {
                alert("Invalid username or password.");
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert("An error occurred while processing your request.");
        });
});